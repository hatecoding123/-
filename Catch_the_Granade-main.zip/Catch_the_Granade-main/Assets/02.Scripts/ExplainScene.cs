using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class ExplainScene : MonoBehaviour
{
    public void btnDown()
    {
        SceneManager.LoadScene("Scene_1");
    }
}
